core-icon-button
================

See the [component page](http://polymer.github.io/core-icon-button) for more information.
