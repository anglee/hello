core-selector
==============

See the [component page](http://polymer.github.io/core-selector) for more information.