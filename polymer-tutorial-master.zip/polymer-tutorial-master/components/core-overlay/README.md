core-overlay
============

See the [component page](http://polymer.github.io/core-overlay) for more information.