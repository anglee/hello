core-drawer-panel
==================

See the [component page](http://polymer.github.io/core-drawer-panel) for more information.
