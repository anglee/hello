core-collapse
=============

See the [component page](http://polymer.github.io/core-collapse) for more information.
