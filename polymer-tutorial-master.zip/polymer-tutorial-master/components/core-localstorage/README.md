core-localstorage
=================

See the [component landing page](http://polymer.github.io/core-localstorage) for more information.
